import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { Preferences } from '@capacitor/preferences';
import { Cliente } from '../models/cliente.model';

@Injectable({
  providedIn: 'root'
})
export class ClienteService {
  private STORAGE_KEY = 'clientes_parqueo_db';
  private clientesSubject = new BehaviorSubject<Cliente[]>([]);
  public clientes$ = this.clientesSubject.asObservable();

  private initialClientes: Cliente[] = [
    {
      clienteId: 1,
      nombre: 'Marvin',
      apellidos: 'Campos',
      cedula: '112340567',
      telefono: '8888-8888',
      correo: 'marvin.campos@ulatina.net',
      activo: true,
      creadoEn: new Date().toISOString()
    },
    {
      clienteId: 2,
      nombre: 'María',
      apellidos: 'Rodríguez',
      cedula: '204560789',
      telefono: '8765-4321',
      correo: 'maria.rodriguez@gmail.com',
      activo: true,
      creadoEn: new Date().toISOString()
    }
  ];

  constructor() {
    this.loadClientes();
  }

  private async loadClientes() {
    const { value } = await Preferences.get({ key: this.STORAGE_KEY });
    if (value) {
      this.clientesSubject.next(JSON.parse(value));
    } else {
      await this.saveClientes(this.initialClientes);
    }
  }

  private async saveClientes(clientes: Cliente[]) {
    await Preferences.set({ key: this.STORAGE_KEY, value: JSON.stringify(clientes) });
    this.clientesSubject.next(clientes);
  }

  getClientes(): Observable<Cliente[]> {
    return this.clientes$;
  }

  getClienteById(id: number): Cliente | undefined {
    return this.clientesSubject.value.find(c => c.clienteId === id);
  }

  async addCliente(cliente: Cliente): Promise<Cliente> {
    const current = this.clientesSubject.value;
    // Validar cédula única
    const exists = current.some(c => c.cedula.toLowerCase() === cliente.cedula.toLowerCase());
    if (exists) {
      throw new Error('La cédula ya se encuentra registrada.');
    }

    const newId = current.length > 0 ? Math.max(...current.map(c => c.clienteId || 0)) + 1 : 1;
    const newCliente: Cliente = {
      ...cliente,
      clienteId: newId,
      creadoEn: new Date().toISOString()
    };

    const updated = [...current, newCliente];
    await this.saveClientes(updated);
    return newCliente;
  }

  async updateCliente(cliente: Cliente): Promise<Cliente> {
    const current = this.clientesSubject.value;
    const index = current.findIndex(c => c.clienteId === cliente.clienteId);
    if (index === -1) throw new Error('Cliente no encontrado');

    // Validar cédula única excluida la propia
    const exists = current.some(c => c.clienteId !== cliente.clienteId && c.cedula.toLowerCase() === cliente.cedula.toLowerCase());
    if (exists) {
      throw new Error('La cédula ya está asignada a otro cliente.');
    }

    const updatedCliente = {
      ...current[index],
      ...cliente,
      actualizadoEn: new Date().toISOString()
    };

    current[index] = updatedCliente;
    await this.saveClientes([...current]);
    return updatedCliente;
  }

  async deleteCliente(id: number): Promise<void> {
    const current = this.clientesSubject.value;
    const updated = current.filter(c => c.clienteId !== id);
    await this.saveClientes(updated);
  }
}
