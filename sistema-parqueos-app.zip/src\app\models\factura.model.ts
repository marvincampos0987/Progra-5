export interface Factura {
  facturaId?: number;
  ingresoId: number;
  fechaFactura: string;
  horasCobradas: number;
  montoTotal: number;
  creadoEn?: string;
  creadoPor?: string;
  actualizadoEn?: string;
  actualizadoPor?: string;
  // Campos auxiliares para la UI
  placaVehiculo?: string;
  clienteNombre?: string;
  parqueoNombre?: string;
}
