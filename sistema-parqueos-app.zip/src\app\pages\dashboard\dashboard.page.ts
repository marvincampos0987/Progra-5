import { Component, OnInit, ElementRef, ViewChild, AfterViewInit } from '@angular/core';
import { IngresoService } from '../../services/ingreso.service';
import { ParqueoService } from '../../services/parqueo.service';
import { FacturaService } from '../../services/factura.service';
import { Chart, registerables } from 'chart.js';

Chart.register(...registerables);

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.page.html',
  styleUrls: ['./dashboard.page.scss'],
  standalone: false
})
export class DashboardPage implements OnInit, AfterViewInit {
  @ViewChild('ingresosChart') ingresosChartRef!: ElementRef<HTMLCanvasElement>;
  chart: any;

  vehiculosIngresadosHoy = 0;
  espaciosDisponibles = 0;
  facturacionDiaria = 0;
  facturacionMensual = 0;

  constructor(
    private ingresoService: IngresoService,
    private parqueoService: ParqueoService,
    private facturaService: FacturaService
  ) {}

  ngOnInit() {
    this.loadMetrics();
  }

  ngAfterViewInit() {
    setTimeout(() => this.initChart(), 300);
  }

  loadMetrics() {
    // 1. Vehículos ingresados hoy
    this.ingresoService.ingresos$.subscribe(ingresos => {
      const hoy = new Date().toDateString();
      this.vehiculosIngresadosHoy = ingresos.filter(i => new Date(i.fechaIngreso).toDateString() === hoy).length;
    });

    // 2. Espacios disponibles
    this.parqueoService.espacios$.subscribe(espacios => {
      this.espaciosDisponibles = espacios.filter(e => e.disponible).length;
    });

    // 3. Facturación diaria y mensual
    this.facturaService.facturas$.subscribe(facturas => {
      const ahora = new Date();
      const hoyStr = ahora.toDateString();
      const mesActual = ahora.getMonth();
      const anioActual = ahora.getFullYear();

      this.facturacionDiaria = facturas
        .filter(f => new Date(f.fechaFactura).toDateString() === hoyStr)
        .reduce((sum, f) => sum + f.montoTotal, 0);

      this.facturacionMensual = facturas
        .filter(f => {
          const d = new Date(f.fechaFactura);
          return d.getMonth() === mesActual && d.getFullYear() === anioActual;
        })
        .reduce((sum, f) => sum + f.montoTotal, 0);
    });
  }

  initChart() {
    if (!this.ingresosChartRef) return;
    const ctx = this.ingresosChartRef.nativeElement.getContext('2d');
    if (!ctx) return;

    if (this.chart) {
      this.chart.destroy();
    }

    this.chart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'],
        datasets: [
          {
            label: 'Facturación (₡)',
            data: [12000, 18500, 24000, 15000, 32000, 28000, 21000],
            backgroundColor: 'rgba(99, 102, 241, 0.7)',
            borderColor: '#6366f1',
            borderWidth: 2,
            borderRadius: 8
          },
          {
            label: 'Vehículos Ingresados',
            data: [10, 15, 20, 12, 25, 22, 18],
            backgroundColor: 'rgba(14, 165, 233, 0.7)',
            borderColor: '#0ea5e9',
            borderWidth: 2,
            borderRadius: 8
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            labels: { color: '#94a3b8', font: { family: 'sans-serif', size: 12 } }
          }
        },
        scales: {
          x: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(255,255,255,0.05)' } },
          y: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(255,255,255,0.05)' } }
        }
      }
    });
  }
}
