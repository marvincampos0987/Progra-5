import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ParqueosPage } from './parqueos.page';

const routes: Routes = [
  {
    path: '',
    component: ParqueosPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ParqueosPageRoutingModule {}
