import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { Preferences } from '@capacitor/preferences';
import { Parqueo } from '../models/parqueo.model';
import { EspacioParqueo } from '../models/espacio-parqueo.model';
import { Tarifa } from '../models/tarifa.model';

@Injectable({
  providedIn: 'root'
})
export class ParqueoService {
  private PARQUEOS_KEY = 'parqueos_db';
  private ESPACIOS_KEY = 'espacios_db';
  private TARIFAS_KEY = 'tarifas_db';

  private parqueosSubject = new BehaviorSubject<Parqueo[]>([]);
  public parqueos$ = this.parqueosSubject.asObservable();

  private espaciosSubject = new BehaviorSubject<EspacioParqueo[]>([]);
  public espacios$ = this.espaciosSubject.asObservable();

  private tarifasSubject = new BehaviorSubject<Tarifa[]>([]);
  public tarifas$ = this.tarifasSubject.asObservable();

  private initialParqueos: Parqueo[] = [
    {
      parqueoId: 1,
      nombreParqueo: 'Parqueo Central San José',
      direccion: 'Av 2, Calle 5, San José',
      telefono: '2222-1111',
      capacidadTotal: 10,
      activo: true,
      creadoEn: new Date().toISOString()
    }
  ];

  private initialEspacios: EspacioParqueo[] = [
    { espacioId: 1, parqueoId: 1, numeroEspacio: 'A-01', disponible: true, activo: true, creadoEn: new Date().toISOString() },
    { espacioId: 2, parqueoId: 1, numeroEspacio: 'A-02', disponible: true, activo: true, creadoEn: new Date().toISOString() },
    { espacioId: 3, parqueoId: 1, numeroEspacio: 'A-03', disponible: false, activo: true, creadoEn: new Date().toISOString() },
    { espacioId: 4, parqueoId: 1, numeroEspacio: 'A-04', disponible: true, activo: true, creadoEn: new Date().toISOString() },
    { espacioId: 5, parqueoId: 1, numeroEspacio: 'A-05', disponible: true, activo: true, creadoEn: new Date().toISOString() }
  ];

  private initialTarifas: Tarifa[] = [
    { tarifaId: 1, tipoVehiculoId: 1, descripcion: 'Automóvil Estándar', montoHora: 1200, activo: true, creadoEn: new Date().toISOString() },
    { tarifaId: 2, tipoVehiculoId: 2, descripcion: 'Motocicleta', montoHora: 600, activo: true, creadoEn: new Date().toISOString() }
  ];

  constructor() {
    this.initData();
  }

  private async initData() {
    const p = await Preferences.get({ key: this.PARQUEOS_KEY });
    if (p.value) {
      this.parqueosSubject.next(JSON.parse(p.value));
    } else {
      await Preferences.set({ key: this.PARQUEOS_KEY, value: JSON.stringify(this.initialParqueos) });
      this.parqueosSubject.next(this.initialParqueos);
    }

    const e = await Preferences.get({ key: this.ESPACIOS_KEY });
    if (e.value) {
      this.espaciosSubject.next(JSON.parse(e.value));
    } else {
      await Preferences.set({ key: this.ESPACIOS_KEY, value: JSON.stringify(this.initialEspacios) });
      this.espaciosSubject.next(this.initialEspacios);
    }

    const t = await Preferences.get({ key: this.TARIFAS_KEY });
    if (t.value) {
      this.tarifasSubject.next(JSON.parse(t.value));
    } else {
      await Preferences.set({ key: this.TARIFAS_KEY, value: JSON.stringify(this.initialTarifas) });
      this.tarifasSubject.next(this.initialTarifas);
    }
  }

  // --- Parqueos ---
  getParqueos(): Observable<Parqueo[]> {
    return this.parqueos$;
  }

  async addParqueo(parqueo: Parqueo): Promise<Parqueo> {
    if (parqueo.capacidadTotal <= 0) {
      throw new Error('La capacidad del parqueo debe ser mayor a cero.');
    }
    const current = this.parqueosSubject.value;
    const newId = current.length > 0 ? Math.max(...current.map(p => p.parqueoId || 0)) + 1 : 1;
    const newP: Parqueo = { ...parqueo, parqueoId: newId, creadoEn: new Date().toISOString() };
    const updated = [...current, newP];
    await Preferences.set({ key: this.PARQUEOS_KEY, value: JSON.stringify(updated) });
    this.parqueosSubject.next(updated);
    return newP;
  }

  // --- Espacios ---
  getEspacios(): Observable<EspacioParqueo[]> {
    return this.espacios$;
  }

  async addEspacio(espacio: EspacioParqueo): Promise<EspacioParqueo> {
    const current = this.espaciosSubject.value;
    // Validar numero de espacio unico por parqueo
    const exists = current.some(e => e.parqueoId === espacio.parqueoId && e.numeroEspacio.toLowerCase() === espacio.numeroEspacio.toLowerCase());
    if (exists) {
      throw new Error('El número de espacio ya existe en este parqueo.');
    }

    const newId = current.length > 0 ? Math.max(...current.map(e => e.espacioId || 0)) + 1 : 1;
    const newE: EspacioParqueo = { ...espacio, espacioId: newId, disponible: true, activo: true, creadoEn: new Date().toISOString() };
    const updated = [...current, newE];
    await Preferences.set({ key: this.ESPACIOS_KEY, value: JSON.stringify(updated) });
    this.espaciosSubject.next(updated);
    return newE;
  }

  async setEspacioDisponible(espacioId: number, disponible: boolean): Promise<void> {
    const current = this.espaciosSubject.value;
    const idx = current.findIndex(e => e.espacioId === espacioId);
    if (idx !== -1) {
      current[idx].disponible = disponible;
      await Preferences.set({ key: this.ESPACIOS_KEY, value: JSON.stringify(current) });
      this.espaciosSubject.next([...current]);
    }
  }

  // --- Tarifas ---
  getTarifas(): Observable<Tarifa[]> {
    return this.tarifas$;
  }

  async addTarifa(tarifa: Tarifa): Promise<Tarifa> {
    if (tarifa.montoHora <= 0) {
      throw new Error('El monto por hora debe ser mayor a cero.');
    }
    const current = this.tarifasSubject.value;
    const newId = current.length > 0 ? Math.max(...current.map(t => t.tarifaId || 0)) + 1 : 1;
    const newT: Tarifa = { ...tarifa, tarifaId: newId, creadoEn: new Date().toISOString() };
    const updated = [...current, newT];
    await Preferences.set({ key: this.TARIFAS_KEY, value: JSON.stringify(updated) });
    this.tarifasSubject.next(updated);
    return newT;
  }
}
