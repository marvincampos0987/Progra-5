import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { ParqueosPageRoutingModule } from './parqueos-routing.module';
import { ParqueosPage } from './parqueos.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    IonicModule,
    ParqueosPageRoutingModule
  ],
  declarations: [ParqueosPage]
})
export class ParqueosPageModule {}
