import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  standalone: false
})
export class LoginPage implements OnInit {
  loginForm!: FormGroup;
  isLoading = false;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit() {
    this.loginForm = this.fb.group({
      correo: ['admin@parqueos.com', [Validators.required, Validators.email]],
      contrasenia: ['admin123', [Validators.required, Validators.minLength(4)]]
    });
  }

  async onLogin() {
    if (this.loginForm.invalid) {
      Swal.fire({
        icon: 'error',
        title: 'Formulario Invalido',
        text: 'Por favor, ingrese un correo válido y su contraseña.',
        heightAuto: false
      });
      return;
    }

    this.isLoading = true;
    const { correo, contrasenia } = this.loginForm.value;

    try {
      const success = await this.authService.login(correo, contrasenia);
      this.isLoading = false;

      if (success) {
        Swal.fire({
          icon: 'success',
          title: 'Bienvenido',
          text: 'Inicio de sesión exitoso',
          timer: 1500,
          showConfirmButton: false,
          heightAuto: false
        });
        this.router.navigate(['/dashboard']);
      } else {
        Swal.fire({
          icon: 'error',
          title: 'Error de Acceso',
          text: 'Credenciales incorrectas.',
          heightAuto: false
        });
      }
    } catch (error: any) {
      this.isLoading = false;
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: error.message || 'Error al iniciar sesión',
        heightAuto: false
      });
    }
  }
}
