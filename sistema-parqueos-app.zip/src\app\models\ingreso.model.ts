export interface IngresoVehiculo {
  ingresoId?: number;
  vehiculoId: number;
  espacioId: number;
  fechaIngreso: string;
  fechaSalida?: string;
  estado: 'ACTIVO' | 'FINALIZADO';
  creadoEn?: string;
  creadoPor?: string;
  actualizadoEn?: string;
  actualizadoPor?: string;
  // Campos auxiliares para la vista
  placaVehiculo?: string;
  numeroEspacio?: string;
  parqueoNombre?: string;
}
