import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { Preferences } from '@capacitor/preferences';
import { Vehiculo } from '../models/vehiculo.model';

@Injectable({
  providedIn: 'root'
})
export class VehiculoService {
  private STORAGE_KEY = 'vehiculos_parqueo_db';
  private vehiculosSubject = new BehaviorSubject<Vehiculo[]>([]);
  public vehiculos$ = this.vehiculosSubject.asObservable();

  private initialVehiculos: Vehiculo[] = [
    {
      vehiculoId: 1,
      clienteId: 1,
      tipoVehiculoId: 1,
      placa: 'ABC-123',
      marca: 'Toyota',
      modelo: 'Corolla',
      color: 'Gris',
      activo: true,
      creadoEn: new Date().toISOString()
    },
    {
      vehiculoId: 2,
      clienteId: 2,
      tipoVehiculoId: 2,
      placa: 'MOT-456',
      marca: 'Yamaha',
      modelo: 'MT-07',
      color: 'Negro',
      activo: true,
      creadoEn: new Date().toISOString()
    }
  ];

  constructor() {
    this.loadVehiculos();
  }

  private async loadVehiculos() {
    const { value } = await Preferences.get({ key: this.STORAGE_KEY });
    if (value) {
      this.vehiculosSubject.next(JSON.parse(value));
    } else {
      await this.saveVehiculos(this.initialVehiculos);
    }
  }

  private async saveVehiculos(vehiculos: Vehiculo[]) {
    await Preferences.set({ key: this.STORAGE_KEY, value: JSON.stringify(vehiculos) });
    this.vehiculosSubject.next(vehiculos);
  }

  getVehiculos(): Observable<Vehiculo[]> {
    return this.vehiculos$;
  }

  getVehiculoById(id: number): Vehiculo | undefined {
    return this.vehiculosSubject.value.find(v => v.vehiculoId === id);
  }

  async addVehiculo(vehiculo: Vehiculo): Promise<Vehiculo> {
    const current = this.vehiculosSubject.value;
    // Validar placa única
    const exists = current.some(v => v.placa.toLowerCase().trim() === vehiculo.placa.toLowerCase().trim());
    if (exists) {
      throw new Error('La placa ya está registrada.');
    }
    if (!vehiculo.clienteId) {
      throw new Error('El cliente es obligatorio.');
    }

    const newId = current.length > 0 ? Math.max(...current.map(v => v.vehiculoId || 0)) + 1 : 1;
    const newVehiculo: Vehiculo = {
      ...vehiculo,
      vehiculoId: newId,
      creadoEn: new Date().toISOString()
    };

    const updated = [...current, newVehiculo];
    await this.saveVehiculos(updated);
    return newVehiculo;
  }

  async updateVehiculo(vehiculo: Vehiculo): Promise<Vehiculo> {
    const current = this.vehiculosSubject.value;
    const index = current.findIndex(v => v.vehiculoId === vehiculo.vehiculoId);
    if (index === -1) throw new Error('Vehículo no encontrado');

    const exists = current.some(v => v.vehiculoId !== vehiculo.vehiculoId && v.placa.toLowerCase().trim() === vehiculo.placa.toLowerCase().trim());
    if (exists) {
      throw new Error('La placa pertenece a otro vehículo.');
    }

    const updatedVehiculo = {
      ...current[index],
      ...vehiculo,
      actualizadoEn: new Date().toISOString()
    };

    current[index] = updatedVehiculo;
    await this.saveVehiculos([...current]);
    return updatedVehiculo;
  }

  async deleteVehiculo(id: number): Promise<void> {
    const current = this.vehiculosSubject.value;
    const updated = current.filter(v => v.vehiculoId !== id);
    await this.saveVehiculos(updated);
  }
}
