import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { Preferences } from '@capacitor/preferences';
import { Factura } from '../models/factura.model';

@Injectable({
  providedIn: 'root'
})
export class FacturaService {
  private STORAGE_KEY = 'facturas_parqueo_db';
  private facturasSubject = new BehaviorSubject<Factura[]>([]);
  public facturas$ = this.facturasSubject.asObservable();

  private initialFacturas: Factura[] = [
    {
      facturaId: 1,
      ingresoId: 100,
      fechaFactura: new Date().toISOString(),
      horasCobradas: 2,
      montoTotal: 2400,
      creadoEn: new Date().toISOString()
    }
  ];

  constructor() {
    this.loadFacturas();
  }

  private async loadFacturas() {
    const { value } = await Preferences.get({ key: this.STORAGE_KEY });
    if (value) {
      this.facturasSubject.next(JSON.parse(value));
    } else {
      await this.saveFacturas(this.initialFacturas);
    }
  }

  private async saveFacturas(facturas: Factura[]) {
    await Preferences.set({ key: this.STORAGE_KEY, value: JSON.stringify(facturas) });
    this.facturasSubject.next(facturas);
  }

  getFacturas(): Observable<Factura[]> {
    return this.facturas$;
  }

  async generarFactura(ingresoId: number, horasCobradas: number, tarifaMontoHora: number): Promise<Factura> {
    const montoTotal = Math.max(0, Math.ceil(horasCobradas) * tarifaMontoHora);

    if (montoTotal < 0) {
      throw new Error('El monto total de la factura no puede ser negativo.');
    }

    const current = this.facturasSubject.value;
    const newId = current.length > 0 ? Math.max(...current.map(f => f.facturaId || 0)) + 1 : 1;

    const nuevaFactura: Factura = {
      facturaId: newId,
      ingresoId,
      fechaFactura: new Date().toISOString(),
      horasCobradas: Math.ceil(horasCobradas),
      montoTotal,
      creadoEn: new Date().toISOString()
    };

    const updated = [...current, nuevaFactura];
    await this.saveFacturas(updated);
    return nuevaFactura;
  }
}
