import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ParqueoService } from '../../services/parqueo.service';
import { Parqueo } from '../../models/parqueo.model';
import { EspacioParqueo } from '../../models/espacio-parqueo.model';
import { Tarifa } from '../../models/tarifa.model';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-parqueos',
  templateUrl: './parqueos.page.html',
  styleUrls: ['./parqueos.page.scss'],
  standalone: false
})
export class ParqueosPage implements OnInit {
  activeSegment: 'parqueos' | 'espacios' | 'tarifas' = 'parqueos';

  parqueos: Parqueo[] = [];
  espacios: EspacioParqueo[] = [];
  tarifas: Tarifa[] = [];

  parqueoForm!: FormGroup;
  espacioForm!: FormGroup;
  tarifaForm!: FormGroup;

  isParqueoModalOpen = false;
  isEspacioModalOpen = false;
  isTarifaModalOpen = false;

  constructor(
    private fb: FormBuilder,
    private parqueoService: ParqueoService
  ) {}

  ngOnInit() {
    this.initForms();

    this.parqueoService.parqueos$.subscribe(p => this.parqueos = p);
    this.parqueoService.espacios$.subscribe(e => {
      this.espacios = e.map(esp => {
        const par = this.parqueos.find(p => p.parqueoId === esp.parqueoId);
        return { ...esp, parqueoNombre: par ? par.nombreParqueo : 'N/A' };
      });
    });
    this.parqueoService.tarifas$.subscribe(t => this.tarifas = t);
  }

  initForms() {
    this.parqueoForm = this.fb.group({
      nombreParqueo: ['', [Validators.required]],
      direccion: ['', [Validators.required]],
      telefono: [''],
      capacidadTotal: [10, [Validators.required, Validators.min(1)]],
      activo: [true]
    });

    this.espacioForm = this.fb.group({
      parqueoId: [null, [Validators.required]],
      numeroEspacio: ['', [Validators.required]]
    });

    this.tarifaForm = this.fb.group({
      tipoVehiculoId: [1, [Validators.required]],
      descripcion: ['', [Validators.required]],
      montoHora: [1000, [Validators.required, Validators.min(1)]],
      activo: [true]
    });
  }

  segmentChanged(ev: any) {
    this.activeSegment = ev.detail.value;
  }

  // --- Parqueos Modal & Actions ---
  openParqueoModal() {
    this.parqueoForm.reset({ capacidadTotal: 10, activo: true });
    this.isParqueoModalOpen = true;
  }

  closeParqueoModal() {
    this.isParqueoModalOpen = false;
  }

  async saveParqueo() {
    if (this.parqueoForm.invalid) {
      Swal.fire({
        icon: 'warning',
        title: 'Datos Incompletos',
        text: 'La capacidad total debe ser mayor a cero.',
        heightAuto: false
      });
      return;
    }
    try {
      await this.parqueoService.addParqueo(this.parqueoForm.value);
      Swal.fire({
        icon: 'success',
        title: 'Parqueo Creado',
        timer: 1500,
        showConfirmButton: false,
        heightAuto: false
      });
      this.closeParqueoModal();
    } catch (e: any) {
      Swal.fire({ icon: 'error', title: 'Error', text: e.message, heightAuto: false });
    }
  }

  // --- Espacios Modal & Actions ---
  openEspacioModal() {
    const defaultParqueoId = this.parqueos.length > 0 ? this.parqueos[0].parqueoId : null;
    this.espacioForm.reset({ parqueoId: defaultParqueoId });
    this.isEspacioModalOpen = true;
  }

  closeEspacioModal() {
    this.isEspacioModalOpen = false;
  }

  async saveEspacio() {
    if (this.espacioForm.invalid) {
      Swal.fire({
        icon: 'warning',
        title: 'Formulario Inválido',
        text: 'Seleccione un parqueo e ingrese el número de espacio.',
        heightAuto: false
      });
      return;
    }
    try {
      await this.parqueoService.addEspacio(this.espacioForm.value);
      Swal.fire({
        icon: 'success',
        title: 'Espacio Agregado',
        timer: 1500,
        showConfirmButton: false,
        heightAuto: false
      });
      this.closeEspacioModal();
    } catch (e: any) {
      Swal.fire({ icon: 'error', title: 'Error', text: e.message, heightAuto: false });
    }
  }

  // --- Tarifas Modal & Actions ---
  openTarifaModal() {
    this.tarifaForm.reset({ tipoVehiculoId: 1, montoHora: 1000, activo: true });
    this.isTarifaModalOpen = true;
  }

  closeTarifaModal() {
    this.isTarifaModalOpen = false;
  }

  async saveTarifa() {
    if (this.tarifaForm.invalid) {
      Swal.fire({
        icon: 'warning',
        title: 'Datos Inválidos',
        text: 'El monto por hora debe ser mayor a cero.',
        heightAuto: false
      });
      return;
    }
    try {
      await this.parqueoService.addTarifa(this.tarifaForm.value);
      Swal.fire({
        icon: 'success',
        title: 'Tarifa Creada',
        timer: 1500,
        showConfirmButton: false,
        heightAuto: false
      });
      this.closeTarifaModal();
    } catch (e: any) {
      Swal.fire({ icon: 'error', title: 'Error', text: e.message, heightAuto: false });
    }
  }
}
