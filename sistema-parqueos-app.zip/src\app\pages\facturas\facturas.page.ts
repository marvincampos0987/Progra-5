import { Component, OnInit } from '@angular/core';
import { FacturaService } from '../../services/factura.service';
import { Factura } from '../../models/factura.model';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-facturas',
  templateUrl: './facturas.page.html',
  styleUrls: ['./facturas.page.scss'],
  standalone: false
})
export class FacturasPage implements OnInit {
  facturas: Factura[] = [];
  filteredFacturas: Factura[] = [];
  searchTerm = '';
  totalRecaudado = 0;

  constructor(private facturaService: FacturaService) {}

  ngOnInit() {
    this.facturaService.facturas$.subscribe(data => {
      this.facturas = data;
      this.calculateTotal();
      this.filterFacturas();
    });
  }

  calculateTotal() {
    this.totalRecaudado = this.facturas.reduce((sum, f) => sum + f.montoTotal, 0);
  }

  filterFacturas() {
    if (!this.searchTerm.trim()) {
      this.filteredFacturas = [...this.facturas];
    } else {
      const term = this.searchTerm.toLowerCase();
      this.filteredFacturas = this.facturas.filter(f =>
        f.facturaId?.toString().includes(term) ||
        f.ingresoId.toString().includes(term)
      );
    }
  }

  verDetalleFactura(factura: Factura) {
    Swal.fire({
      title: `Factura #${factura.facturaId}`,
      html: `
        <div style="text-align: left; font-size: 0.95rem; color: #334155;">
          <p><strong>Fecha:</strong> ${new Date(factura.fechaFactura).toLocaleString()}</p>
          <p><strong>Ingreso ID:</strong> #${factura.ingresoId}</p>
          <p><strong>Horas cobradas:</strong> ${factura.horasCobradas} hr(s)</p>
          <hr style="border: 0; border-top: 1px solid #e2e8f0; margin: 12px 0;"/>
          <h3 style="color: #0f172a; margin: 0; font-size: 1.3rem;">Total: ₡${factura.montoTotal.toLocaleString()}</h3>
        </div>
      `,
      icon: 'info',
      confirmButtonText: 'Cerrar',
      confirmButtonColor: '#6366f1',
      heightAuto: false
    });
  }
}
