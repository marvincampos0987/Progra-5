export interface Vehiculo {
  vehiculoId?: number;
  clienteId: number;
  tipoVehiculoId: number;
  placa: string;
  marca: string;
  modelo?: string;
  color?: string;
  activo: boolean;
  creadoEn?: string;
  creadoPor?: string;
  actualizadoEn?: string;
  actualizadoPor?: string;
  // Campos poblados para UI
  clienteNombre?: string;
  tipoVehiculoDescripcion?: string;
}
