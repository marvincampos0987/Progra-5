import { Injectable } from '@angular/core';
import { Preferences } from '@capacitor/preferences';
import { jwtDecode } from 'jwt-decode';
import { BehaviorSubject, Observable } from 'rxjs';

export interface UserTokenPayload {
  sub: string;
  email: string;
  role: string;
  exp: number;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private isAuthenticatedSubject = new BehaviorSubject<boolean>(false);
  public isAuthenticated$: Observable<boolean> = this.isAuthenticatedSubject.asObservable();
  private currentUserSubject = new BehaviorSubject<string | null>(null);
  public currentUser$: Observable<string | null> = this.currentUserSubject.asObservable();

  constructor() {
    this.checkToken();
  }

  private async checkToken() {
    const { value } = await Preferences.get({ key: 'auth_token' });
    if (value) {
      try {
        const decoded = jwtDecode<UserTokenPayload>(value);
        if (decoded.exp * 1000 > Date.now()) {
          this.isAuthenticatedSubject.next(true);
          this.currentUserSubject.next(decoded.email || 'Usuario Parqueos');
        } else {
          await this.logout();
        }
      } catch (e) {
        // En caso de mock token simple:
        this.isAuthenticatedSubject.next(true);
        this.currentUserSubject.next('Admin');
      }
    }
  }

  async login(correo: string, contrasenia: string): Promise<boolean> {
    if (correo && contrasenia) {
      // Simulación de JWT token válido
      const mockHeader = btoa(JSON.stringify({ alg: "HS256", typ: "JWT" }));
      const mockPayload = btoa(JSON.stringify({
        sub: "1234567890",
        name: "Admin Parqueo",
        email: correo,
        role: "Administrador",
        exp: Math.floor(Date.now() / 1000) + (60 * 60 * 24)
      }));
      const mockToken = `${mockHeader}.${mockPayload}.signature`;

      await Preferences.set({ key: 'auth_token', value: mockToken });
      this.isAuthenticatedSubject.next(true);
      this.currentUserSubject.next(correo);
      return true;
    }
    return false;
  }

  async logout(): Promise<void> {
    await Preferences.remove({ key: 'auth_token' });
    this.isAuthenticatedSubject.next(false);
    this.currentUserSubject.next(null);
  }

  async getToken(): Promise<string | null> {
    const { value } = await Preferences.get({ key: 'auth_token' });
    return value;
  }
}
