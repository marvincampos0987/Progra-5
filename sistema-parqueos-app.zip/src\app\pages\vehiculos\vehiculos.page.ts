import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { VehiculoService } from '../../services/vehiculo.service';
import { ClienteService } from '../../services/cliente.service';
import { Vehiculo } from '../../models/vehiculo.model';
import { Cliente } from '../../models/cliente.model';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-vehiculos',
  templateUrl: './vehiculos.page.html',
  styleUrls: ['./vehiculos.page.scss'],
  standalone: false
})
export class VehiculosPage implements OnInit {
  vehiculos: Vehiculo[] = [];
  filteredVehiculos: Vehiculo[] = [];
  clientes: Cliente[] = [];
  vehiculoForm!: FormGroup;

  isModalOpen = false;
  isEditMode = false;
  selectedVehiculoId: number | null = null;
  searchTerm = '';

  tiposVehiculo = [
    { id: 1, descripcion: 'Automóvil' },
    { id: 2, descripcion: 'Motocicleta' },
    { id: 3, descripcion: 'Camión/Pickup' }
  ];

  constructor(
    private fb: FormBuilder,
    private vehiculoService: VehiculoService,
    private clienteService: ClienteService
  ) {}

  ngOnInit() {
    this.initForm();

    this.clienteService.clientes$.subscribe(cls => this.clientes = cls);

    this.vehiculoService.vehiculos$.subscribe(data => {
      this.vehiculos = data.map(v => {
        const clienteObj = this.clientes.find(c => c.clienteId === v.clienteId);
        const tipoObj = this.tiposVehiculo.find(t => t.id === v.tipoVehiculoId);
        return {
          ...v,
          clienteNombre: clienteObj ? `${clienteObj.nombre} ${clienteObj.apellidos}` : 'Desconocido',
          tipoVehiculoDescripcion: tipoObj ? tipoObj.descripcion : 'Vehículo'
        };
      });
      this.filterVehiculos();
    });
  }

  initForm() {
    this.vehiculoForm = this.fb.group({
      clienteId: [null, [Validators.required]],
      tipoVehiculoId: [1, [Validators.required]],
      placa: ['', [Validators.required, Validators.minLength(3)]],
      marca: ['', [Validators.required]],
      modelo: [''],
      color: [''],
      activo: [true]
    });
  }

  filterVehiculos() {
    if (!this.searchTerm.trim()) {
      this.filteredVehiculos = [...this.vehiculos];
    } else {
      const term = this.searchTerm.toLowerCase();
      this.filteredVehiculos = this.vehiculos.filter(v =>
        v.placa.toLowerCase().includes(term) ||
        v.marca.toLowerCase().includes(term) ||
        (v.clienteNombre && v.clienteNombre.toLowerCase().includes(term))
      );
    }
  }

  openCreateModal() {
    this.isEditMode = false;
    this.selectedVehiculoId = null;
    this.vehiculoForm.reset({ tipoVehiculoId: 1, activo: true });
    this.isModalOpen = true;
  }

  openEditModal(vehiculo: Vehiculo) {
    this.isEditMode = true;
    this.selectedVehiculoId = vehiculo.vehiculoId || null;
    this.vehiculoForm.patchValue({
      clienteId: vehiculo.clienteId,
      tipoVehiculoId: vehiculo.tipoVehiculoId,
      placa: vehiculo.placa,
      marca: vehiculo.marca,
      modelo: vehiculo.modelo || '',
      color: vehiculo.color || '',
      activo: vehiculo.activo
    });
    this.isModalOpen = true;
  }

  closeModal() {
    this.isModalOpen = false;
  }

  async saveVehiculo() {
    if (this.vehiculoForm.invalid) {
      Swal.fire({
        icon: 'warning',
        title: 'Campos Incompletos',
        text: 'Debe seleccionar un cliente obligatorio, ingresar la marca y una placa única.',
        heightAuto: false
      });
      return;
    }

    const formValues = this.vehiculoForm.value;

    try {
      if (this.isEditMode && this.selectedVehiculoId) {
        await this.vehiculoService.updateVehiculo({
          vehiculoId: this.selectedVehiculoId,
          ...formValues
        });
        Swal.fire({
          icon: 'success',
          title: 'Actualizado',
          text: 'Vehículo actualizado correctamente.',
          timer: 1500,
          showConfirmButton: false,
          heightAuto: false
        });
      } else {
        await this.vehiculoService.addVehiculo(formValues);
        Swal.fire({
          icon: 'success',
          title: 'Registrado',
          text: 'Vehículo registrado correctamente.',
          timer: 1500,
          showConfirmButton: false,
          heightAuto: false
        });
      }
      this.closeModal();
    } catch (error: any) {
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: error.message || 'No se pudo guardar el vehículo.',
        heightAuto: false
      });
    }
  }

  async confirmDelete(vehiculo: Vehiculo) {
    const result = await Swal.fire({
      title: '¿Eliminar vehículo?',
      text: `Placa: ${vehiculo.placa} - Marca: ${vehiculo.marca}`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#ef4444',
      cancelButtonColor: '#64748b',
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar',
      heightAuto: false
    });

    if (result.isConfirmed && vehiculo.vehiculoId) {
      try {
        await this.vehiculoService.deleteVehiculo(vehiculo.vehiculoId);
        Swal.fire({
          icon: 'success',
          title: 'Eliminado',
          text: 'El vehículo ha sido eliminado.',
          timer: 1500,
          showConfirmButton: false,
          heightAuto: false
        });
      } catch (error: any) {
        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: error.message || 'No se pudo eliminar el vehículo.',
          heightAuto: false
        });
      }
    }
  }
}
