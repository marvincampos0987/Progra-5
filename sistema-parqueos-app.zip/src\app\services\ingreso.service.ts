import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { Preferences } from '@capacitor/preferences';
import { IngresoVehiculo } from '../models/ingreso.model';
import { ParqueoService } from './parqueo.service';

@Injectable({
  providedIn: 'root'
})
export class IngresoService {
  private STORAGE_KEY = 'ingresos_parqueo_db';
  private ingresosSubject = new BehaviorSubject<IngresoVehiculo[]>([]);
  public ingresos$ = this.ingresosSubject.asObservable();

  private initialIngresos: IngresoVehiculo[] = [
    {
      ingresoId: 1,
      vehiculoId: 1,
      espacioId: 3,
      fechaIngreso: new Date(Date.now() - 3600000 * 3).toISOString(), // 3 horas atras
      estado: 'ACTIVO',
      creadoEn: new Date().toISOString()
    }
  ];

  constructor(private parqueoService: ParqueoService) {
    this.loadIngresos();
  }

  private async loadIngresos() {
    const { value } = await Preferences.get({ key: this.STORAGE_KEY });
    if (value) {
      this.ingresosSubject.next(JSON.parse(value));
    } else {
      await this.saveIngresos(this.initialIngresos);
    }
  }

  private async saveIngresos(ingresos: IngresoVehiculo[]) {
    await Preferences.set({ key: this.STORAGE_KEY, value: JSON.stringify(ingresos) });
    this.ingresosSubject.next(ingresos);
  }

  getIngresos(): Observable<IngresoVehiculo[]> {
    return this.ingresos$;
  }

  async registrarIngreso(vehiculoId: number, espacioId: number): Promise<IngresoVehiculo> {
    // Validar disponibilidad de espacio
    const espacios = this.parqueoService.espacios$;
    let espacioValido = false;

    const currentEspacios = (this.parqueoService as any).espaciosSubject.value;
    const espacioObj = currentEspacios.find((e: any) => e.espacioId === espacioId);

    if (!espacioObj || !espacioObj.disponible) {
      throw new Error('No hay espacios disponibles en la ubicación seleccionada.');
    }

    const currentIngresos = this.ingresosSubject.value;
    // Verificar si el vehículo ya está parqueado
    const yaParqueado = currentIngresos.some(i => i.vehiculoId === vehiculoId && i.estado === 'ACTIVO');
    if (yaParqueado) {
      throw new Error('Este vehículo ya registra un ingreso activo.');
    }

    const newId = currentIngresos.length > 0 ? Math.max(...currentIngresos.map(i => i.ingresoId || 0)) + 1 : 1;
    const nuevoIngreso: IngresoVehiculo = {
      ingresoId: newId,
      vehiculoId,
      espacioId,
      fechaIngreso: new Date().toISOString(),
      estado: 'ACTIVO',
      creadoEn: new Date().toISOString()
    };

    // Marcar espacio como ocupado
    await this.parqueoService.setEspacioDisponible(espacioId, false);

    const updated = [...currentIngresos, nuevoIngreso];
    await this.saveIngresos(updated);
    return nuevoIngreso;
  }

  async registrarSalida(ingresoId: number): Promise<IngresoVehiculo> {
    const current = this.ingresosSubject.value;
    const idx = current.findIndex(i => i.ingresoId === ingresoId);
    if (idx === -1) throw new Error('Registro de ingreso no encontrado');

    const ingreso = current[idx];
    if (ingreso.estado === 'FINALIZADO') {
      throw new Error('El ingreso ya fue finalizado.');
    }

    const fechaSalida = new Date().toISOString();
    ingreso.fechaSalida = fechaSalida;
    ingreso.estado = 'FINALIZADO';

    // Liberar espacio
    await this.parqueoService.setEspacioDisponible(ingreso.espacioId, true);

    current[idx] = ingreso;
    await this.saveIngresos([...current]);
    return ingreso;
  }
}
