import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from './services/auth.service';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
  standalone: false,
})
export class AppComponent {
  public appPages = [
    { title: 'Dashboard', url: '/dashboard', icon: 'speedometer' },
    { title: 'Clientes', url: '/clientes', icon: 'people' },
    { title: 'Vehículos', url: '/vehiculos', icon: 'car' },
    { title: 'Parqueos & Espacios', url: '/parqueos', icon: 'business' },
    { title: 'Ingresos & Salidas', url: '/ingresos', icon: 'log-in' },
    { title: 'Facturas', url: '/facturas', icon: 'receipt' },
  ];

  public currentUser: string | null = null;
  public isAuthenticated = false;

  constructor(private authService: AuthService, private router: Router) {
    this.authService.currentUser$.subscribe(user => this.currentUser = user);
    this.authService.isAuthenticated$.subscribe(auth => this.isAuthenticated = auth);
  }

  async logout() {
    await this.authService.logout();
    this.router.navigate(['/login']);
  }
}
