import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ClienteService } from '../../services/cliente.service';
import { Cliente } from '../../models/cliente.model';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-clientes',
  templateUrl: './clientes.page.html',
  styleUrls: ['./clientes.page.scss'],
  standalone: false
})
export class ClientesPage implements OnInit {
  clientes: Cliente[] = [];
  filteredClientes: Cliente[] = [];
  clienteForm!: FormGroup;
  isModalOpen = false;
  isEditMode = false;
  selectedClienteId: number | null = null;
  searchTerm = '';

  constructor(
    private fb: FormBuilder,
    private clienteService: ClienteService
  ) {}

  ngOnInit() {
    this.initForm();
    this.clienteService.clientes$.subscribe(data => {
      this.clientes = data;
      this.filterClientes();
    });
  }

  initForm() {
    this.clienteForm = this.fb.group({
      nombre: ['', [Validators.required, Validators.minLength(2)]],
      apellidos: ['', [Validators.required]],
      cedula: ['', [Validators.required]],
      telefono: [''],
      correo: ['', [Validators.email]],
      activo: [true]
    });
  }

  filterClientes() {
    if (!this.searchTerm.trim()) {
      this.filteredClientes = [...this.clientes];
    } else {
      const term = this.searchTerm.toLowerCase();
      this.filteredClientes = this.clientes.filter(c =>
        c.nombre.toLowerCase().includes(term) ||
        c.apellidos.toLowerCase().includes(term) ||
        c.cedula.toLowerCase().includes(term) ||
        (c.correo && c.correo.toLowerCase().includes(term))
      );
    }
  }

  openCreateModal() {
    this.isEditMode = false;
    this.selectedClienteId = null;
    this.clienteForm.reset({ activo: true });
    this.isModalOpen = true;
  }

  openEditModal(cliente: Cliente) {
    this.isEditMode = true;
    this.selectedClienteId = cliente.clienteId || null;
    this.clienteForm.patchValue({
      nombre: cliente.nombre,
      apellidos: cliente.apellidos,
      cedula: cliente.cedula,
      telefono: cliente.telefono || '',
      correo: cliente.correo || '',
      activo: cliente.activo
    });
    this.isModalOpen = true;
  }

  closeModal() {
    this.isModalOpen = false;
  }

  async saveCliente() {
    if (this.clienteForm.invalid) {
      Swal.fire({
        icon: 'warning',
        title: 'Campos requeridos',
        text: 'Por favor complete correctamente los datos (nombre, apellidos, cédula y correo válido).',
        heightAuto: false
      });
      return;
    }

    const formValues = this.clienteForm.value;

    try {
      if (this.isEditMode && this.selectedClienteId) {
        await this.clienteService.updateCliente({
          clienteId: this.selectedClienteId,
          ...formValues
        });
        Swal.fire({
          icon: 'success',
          title: 'Actualizado',
          text: 'Cliente actualizado correctamente.',
          timer: 1500,
          showConfirmButton: false,
          heightAuto: false
        });
      } else {
        await this.clienteService.addCliente(formValues);
        Swal.fire({
          icon: 'success',
          title: 'Registrado',
          text: 'Cliente registrado correctamente.',
          timer: 1500,
          showConfirmButton: false,
          heightAuto: false
        });
      }
      this.closeModal();
    } catch (error: any) {
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: error.message || 'Ocurrió un error al guardar.',
        heightAuto: false
      });
    }
  }

  async confirmDelete(cliente: Cliente) {
    const result = await Swal.fire({
      title: '¿Eliminar cliente?',
      text: `Se eliminará a ${cliente.nombre} ${cliente.apellidos}`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#ef4444',
      cancelButtonColor: '#64748b',
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar',
      heightAuto: false
    });

    if (result.isConfirmed && cliente.clienteId) {
      try {
        await this.clienteService.deleteCliente(cliente.clienteId);
        Swal.fire({
          icon: 'success',
          title: 'Eliminado',
          text: 'El cliente ha sido eliminado.',
          timer: 1500,
          showConfirmButton: false,
          heightAuto: false
        });
      } catch (error: any) {
        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: error.message || 'No se pudo eliminar el cliente.',
          heightAuto: false
        });
      }
    }
  }
}
