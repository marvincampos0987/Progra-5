export interface EspacioParqueo {
  espacioId?: number;
  parqueoId: number;
  numeroEspacio: string;
  disponible: boolean;
  activo: boolean;
  creadoEn?: string;
  creadoPor?: string;
  actualizadoEn?: string;
  actualizadoPor?: string;
  // Propiedad para UI
  parqueoNombre?: string;
}
