export interface Tarifa {
  tarifaId?: number;
  tipoVehiculoId: number;
  descripcion: string;
  montoHora: number;
  activo: boolean;
  creadoEn?: string;
  creadoPor?: string;
  actualizadoEn?: string;
  actualizadoPor?: string;
  tipoVehiculoDescripcion?: string;
}
