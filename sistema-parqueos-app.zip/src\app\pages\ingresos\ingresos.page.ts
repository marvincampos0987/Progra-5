import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { IngresoService } from '../../services/ingreso.service';
import { VehiculoService } from '../../services/vehiculo.service';
import { ParqueoService } from '../../services/parqueo.service';
import { FacturaService } from '../../services/factura.service';
import { IngresoVehiculo } from '../../models/ingreso.model';
import { Vehiculo } from '../../models/vehiculo.model';
import { EspacioParqueo } from '../../models/espacio-parqueo.model';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-ingresos',
  templateUrl: './ingresos.page.html',
  styleUrls: ['./ingresos.page.scss'],
  standalone: false
})
export class IngresosPage implements OnInit {
  ingresos: IngresoVehiculo[] = [];
  vehiculos: Vehiculo[] = [];
  espaciosDisponibles: EspacioParqueo[] = [];

  ingresoForm!: FormGroup;
  isModalOpen = false;

  constructor(
    private fb: FormBuilder,
    private ingresoService: IngresoService,
    private vehiculoService: VehiculoService,
    private parqueoService: ParqueoService,
    private facturaService: FacturaService
  ) {}

  ngOnInit() {
    this.initForm();

    this.vehiculoService.vehiculos$.subscribe(v => this.vehiculos = v.filter(veh => veh.activo));

    this.parqueoService.espacios$.subscribe(esp => {
      this.espaciosDisponibles = esp.filter(e => e.disponible && e.activo);
    });

    this.ingresoService.ingresos$.subscribe(ing => {
      const allEspacios = (this.parqueoService as any).espaciosSubject.value;
      this.ingresos = ing.map(i => {
        const veh = this.vehiculos.find(v => v.vehiculoId === i.vehiculoId);
        const esp = allEspacios.find((e: any) => e.espacioId === i.espacioId);
        return {
          ...i,
          placaVehiculo: veh ? veh.placa : 'N/A',
          numeroEspacio: esp ? esp.numeroEspacio : 'N/A'
        };
      });
    });
  }

  initForm() {
    this.ingresoForm = this.fb.group({
      vehiculoId: [null, [Validators.required]],
      espacioId: [null, [Validators.required]]
    });
  }

  openIngresoModal() {
    if (this.espaciosDisponibles.length === 0) {
      Swal.fire({
        icon: 'error',
        title: 'Sin Espacios Disponibles',
        text: 'No es posible registrar ingresos porque el parqueo está al 100% de capacidad.',
        heightAuto: false
      });
      return;
    }

    const defaultEspacio = this.espaciosDisponibles[0]?.espacioId || null;
    const defaultVehiculo = this.vehiculos[0]?.vehiculoId || null;

    this.ingresoForm.reset({
      vehiculoId: defaultVehiculo,
      espacioId: defaultEspacio
    });
    this.isModalOpen = true;
  }

  closeModal() {
    this.isModalOpen = false;
  }

  async registrarIngreso() {
    if (this.ingresoForm.invalid) {
      Swal.fire({
        icon: 'warning',
        title: 'Selección Requerida',
        text: 'Seleccione un vehículo y un espacio disponible.',
        heightAuto: false
      });
      return;
    }

    const { vehiculoId, espacioId } = this.ingresoForm.value;

    try {
      await this.ingresoService.registrarIngreso(vehiculoId, espacioId);
      Swal.fire({
        icon: 'success',
        title: 'Ingreso Exitoso',
        text: 'Vehículo ingresado al parqueo.',
        timer: 1500,
        showConfirmButton: false,
        heightAuto: false
      });
      this.closeModal();
    } catch (error: any) {
      Swal.fire({
        icon: 'error',
        title: 'Error al Ingresar',
        text: error.message || 'No se pudo realizar el ingreso.',
        heightAuto: false
      });
    }
  }

  async procesarSalida(ingreso: IngresoVehiculo) {
    if (!ingreso.ingresoId) return;

    const result = await Swal.fire({
      title: '¿Procesar Salida y Facturar?',
      text: `Vehículo Placa ${ingreso.placaVehiculo} - Espacio ${ingreso.numeroEspacio}`,
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#10b981',
      cancelButtonColor: '#64748b',
      confirmButtonText: 'Sí, registrar salida',
      cancelButtonText: 'Cancelar',
      heightAuto: false
    });

    if (result.isConfirmed) {
      try {
        const finalizado = await this.ingresoService.registrarSalida(ingreso.ingresoId);

        // Calcular horas transcurridas
        const entrada = new Date(finalizado.fechaIngreso).getTime();
        const salida = new Date(finalizado.fechaSalida!).getTime();
        const diffHoras = Math.max(1, (salida - entrada) / (1000 * 60 * 60));

        // Obtener tarifa
        const tarifaHora = 1200; // Tarifa estándar
        const factura = await this.facturaService.generarFactura(finalizado.ingresoId!, diffHoras, tarifaHora);

        Swal.fire({
          icon: 'success',
          title: 'Salida Registrada',
          html: `
            <p><strong>Horas cobradas:</strong> ${factura.horasCobradas} hrs</p>
            <p><strong>Monto Total:</strong> ₡${factura.montoTotal}</p>
          `,
          heightAuto: false
        });
      } catch (error: any) {
        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: error.message || 'No se pudo registrar la salida.',
          heightAuto: false
        });
      }
    }
  }
}
